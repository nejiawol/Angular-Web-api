import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-show-cour',
  templateUrl: './show-cour.component.html',
  styleUrls: ['./show-cour.component.css']
})
export class ShowCourComponent implements OnInit {

  constructor(private service:SharedService) { }
  CourseList:any=[];
  ModalTitle:string;
  ActivateAddEditcourcomp:boolean=false;
  cour:any;

  CourseIdFilter:string="";
  CourseTitleFilter:string="";
  CourseCreditFilter:string="";
  CourseClassroomFilter:string="";
  CourseListwithoutFilter:any=[];


  ngOnInit(): void {
    this.refreshcourlist();
  }

  addClick(){

    this.cour={
      CourseId:0,
      CourseTitle:"",
      CourseCredit:0,
      Classroom:0
}
    this.ModalTitle="Add Course";
    this.ActivateAddEditcourcomp=true;

  }

  editClick(item){
      this.cour=item;
      this.ModalTitle="Edit Courses";
      this.ActivateAddEditcourcomp=true;

  }

  deleteClick(item){
     if(confirm('are you sure!')){
         this.service.deleteCourse(item.CourseId).subscribe(data=>{
            alert(data.toString());
            this.refreshcourlist();

         })
     }

  }
  closeClick(){

    this.ActivateAddEditcourcomp=false;
    this.refreshcourlist();
  }


  refreshcourlist(){
    this.service.getCourseList().subscribe(data=>{
        this.CourseList=data;
        this.CourseListwithoutFilter=data;
    });
  }

  FilterFun(){

    var CourseIdFilter= this.CourseIdFilter;
    var CourseCreditFilter= this.CourseCreditFilter;
    var CourseTitleFilter= this.CourseTitleFilter;
    var CourseClassroomFilter= this.CourseClassroomFilter;

    this.CourseList= this.CourseListwithoutFilter.filter(function (e1){
        return e1.CourseId.toString().toLowerCase().includes(
          CourseIdFilter.toString().trim().toLowerCase()
        )&& 
        e1.CourseTitle.toString().toLowerCase().includes(

          CourseTitleFilter.toString().trim().toLowerCase()
        )&&
        e1.CourseCredit.toString().toLowerCase().includes(

          CourseCreditFilter.toString().trim().toLowerCase()
        )&&
        e1.Classroom.toString().toLowerCase().includes(

          CourseClassroomFilter.toString().trim().toLowerCase()
        )
        

    });
}
}
