import { Component, OnInit,Input } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-cour',
  templateUrl: './add-edit-cour.component.html',
  styleUrls: ['./add-edit-cour.component.css']
})
export class AddEditCourComponent implements OnInit {

  constructor(private service:SharedService) { }
  @Input() cour:any;

  CourseId:string;
  CourseTitle:string;
  CourseCredit:string;
  Classroom:string;



  ngOnInit(): void {
    this.CourseId=this.cour.CourseId;
    this.CourseTitle=this.cour.CourseTitle;
    this.CourseCredit=this.cour.CourseCredit;
    this.Classroom=this.cour.Classroom;
  }

  Addcourse(){
    var val = { CourseId:this.CourseId,
               CourseTitle:this.CourseTitle,
               CourseCredit:this.CourseCredit,
               Classroom:this.Classroom};
          this.service.addCourse(val).subscribe(res=>{
            alert(res.toString());
          });
    
            }

        
  Editcourse(){
    var val = { CourseId:this.CourseId,
      CourseTitle:this.CourseTitle,
      CourseCredit:this.CourseCredit,
      Classroom:this.Classroom};
 this.service.updateCourse(val).subscribe(res=>{
   alert(res.toString());
 });

  }
}
