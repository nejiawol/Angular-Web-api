import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-show-stu',
  templateUrl: './show-stu.component.html',
  styleUrls: ['./show-stu.component.css']
})
export class ShowStuComponent implements OnInit {

  constructor(private service:SharedService) { }
  StudentList:any=[];
  ModalTitle:string;
  ActivateAddEditstucomp:boolean=false;
  stu:any;

  StudentIdFilter:string="";
  StudentNameFilter:string="";
  StudentMajorFilter:string="";
  StudentListwithoutFilter:any=[];

  ngOnInit(): void {
    this.refreshstulist();
  }

  addClick(){

    this.stu={
      StudentId:0,
      StudentName:"",
      StudentMajor:"",
      photofilename:"anonymous.png"
}
    this.ModalTitle="Add Student";
    this.ActivateAddEditstucomp=true;

  }

  editClick(item){
      this.stu=item;
      this.ModalTitle="Edit Student";
      this.ActivateAddEditstucomp=true;

  }

  deleteClick(item){
     if(confirm('are you sure!')){
         this.service.deleteStudent(item.StudentId).subscribe(data=>{
            alert(data.toString());
            this.refreshstulist();

         })
     }

  }
  closeClick(){

    this.ActivateAddEditstucomp=false;
    this.refreshstulist();
  }


  refreshstulist(){
    this.service.getStuList().subscribe(data=>{
        this.StudentList=data;
        this.StudentListwithoutFilter=data;
    });
  }

  FiltFun(){

    var StudentIdFilter= this.StudentIdFilter;
    var StudentNameFilter= this.StudentNameFilter;
    var StudentMajorFilter= this.StudentMajorFilter;


    this.StudentList= this.StudentListwithoutFilter.filter(function (e1){
        return e1.StudentId.toString().toLowerCase().includes(
          StudentIdFilter.toString().trim().toLowerCase()
        )&& 
        e1.StudentName.toString().toLowerCase().includes(

          StudentNameFilter.toString().trim().toLowerCase()
        )&&
        e1.StudentMajor.toString().toLowerCase().includes(

          StudentMajorFilter.toString().trim().toLowerCase()
        )

    });
}
}
