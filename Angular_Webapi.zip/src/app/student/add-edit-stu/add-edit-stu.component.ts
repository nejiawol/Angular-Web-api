import { Component, OnInit,Input } from '@angular/core';
import { SharedService } from 'src/app/shared.service';
import {MatSelectModule} from '@angular/material/select';

@Component({
  selector: 'app-add-edit-stu',
  templateUrl: './add-edit-stu.component.html',
  styleUrls: ['./add-edit-stu.component.css']
})
export class AddEditStuComponent implements OnInit {

  constructor(private service:SharedService) { }
  @Input() stu:any;

  StudentId:string;
  StudentName:string;
  StudentMajor:string;
  photofilename:string;
  photofilepath:string;

  MajorList:any=[];



  ngOnInit(): void {
    this.loadMajorList();
  }

  loadMajorList(){
     this.service.getallCourses().subscribe((data:any)=>{
       this.MajorList=data;

      this.StudentId=this.stu.StudentId;
      this.StudentName=this.stu.StudentName;
      this.StudentMajor=this.stu.StudentMajor;
      this.photofilename=this.stu.photofilename;
      this.photofilepath= this.service.PhotoUrl+this.photofilename;


     });

     }

  Addstudent(){
    var val = { StudentId:this.StudentId,
               StudentName:this.StudentName,
               StudentMajor:this.StudentMajor,
               photofilename:this.photofilename};
          this.service.addStudent(val).subscribe(res=>{
            alert(res.toString());
          });
    
            }

        
  Editstudent(){
    var val = { StudentId:this.StudentId,
      StudentName:this.StudentName,
      StudentMajor:this.StudentMajor,
      photofilename:this.photofilename};
 this.service.updateStudent(val).subscribe(res=>{
   alert(res.toString());
 });

  }

    uploadPhoto(event){
      var file=event.target.files[0];
      const formData:FormData=new FormData();
      formData.append('uploadedFile',file,file.name);

      this.service.Uploadphoto(formData).subscribe((data:any)=>{

        this.photofilename=data.toString();
        this.photofilepath=this.service.PhotoUrl+this.photofilename;
      })

    }

}
