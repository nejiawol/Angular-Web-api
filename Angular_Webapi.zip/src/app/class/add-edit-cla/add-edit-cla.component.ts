import { Component, OnInit,Input } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-cla',
  templateUrl: './add-edit-cla.component.html',
  styleUrls: ['./add-edit-cla.component.css']
})
export class AddEditClaComponent implements OnInit {

  constructor(private service:SharedService) { }
  @Input() cla:any;

  ClassId:string;
  ClassroomType:string;
  ClassroomCapacity:string;




  ngOnInit(): void {
    this.ClassId=this.cla.ClassId;
    this.ClassroomType=this.cla.ClassroomType;
    this.ClassroomCapacity=this.cla.ClassroomCapacity;
 
  }

  Addclass(){
    var val = { ClassId:this.ClassId,
               ClassroomType:this.ClassroomType,
               ClassroomCapacity:this.ClassroomCapacity};
          this.service.addClass(val).subscribe(res=>{
            alert(res.toString());
          });
    
            }

        
  Editclass(){
    var val = { ClassId:this.ClassId,
      ClassroomType:this.ClassroomType,
      ClassroomCapacity:this.ClassroomCapacity
     };
 this.service.updateClass(val).subscribe(res=>{
   alert(res.toString());
 });

  }
}
