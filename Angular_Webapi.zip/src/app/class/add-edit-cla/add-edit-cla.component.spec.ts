import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditClaComponent } from './add-edit-cla.component';

describe('AddEditClaComponent', () => {
  let component: AddEditClaComponent;
  let fixture: ComponentFixture<AddEditClaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditClaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditClaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
