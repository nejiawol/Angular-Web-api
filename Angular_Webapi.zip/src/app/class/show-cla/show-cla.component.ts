import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-show-cla',
  templateUrl: './show-cla.component.html',
  styleUrls: ['./show-cla.component.css']
})
export class ShowClaComponent implements OnInit {

  constructor(private service:SharedService) { }
  ClassList:any=[];
  ModalTitle:string;
  ActivateAddEditclacomp:boolean=false;
  cla:any;

  ClassIdFilter:string="";
  ClassroomTypeFilter:string="";
  ClassroomCapacityFilter:string="";
  ClassListwithoutFilter:any=[];


  ngOnInit(): void {
    this.refreshclalist();
  }

  addClick(){

    this.cla={
      ClassId:0,
      ClassroomType:"",
      ClassroomCapacity:0,
}
    this.ModalTitle="Add Class";
    this.ActivateAddEditclacomp=true;

  }

  editClick(item){
      this.cla=item;
      this.ModalTitle="Edit Class";
      this.ActivateAddEditclacomp=true;

  }

  deleteClick(item){
     if(confirm('are you sure!')){
         this.service.deleteClass(item.ClassId).subscribe(data=>{
            alert(data.toString());
            this.refreshclalist();

         })
     }

  }
  closeClick(){

    this.ActivateAddEditclacomp=false;
    this.refreshclalist();
  }


  refreshclalist(){
    this.service.getClassList().subscribe(data=>{
        this.ClassList=data;
        this.ClassListwithoutFilter=data;
    });
  }

  FilFun(){

    var ClassIdFilter= this.ClassIdFilter;
    var ClassroomTypeFilter= this.ClassroomTypeFilter;
    var ClassroomCapacityFilter= this.ClassroomCapacityFilter;

    this.ClassList= this.ClassListwithoutFilter.filter(function (e1){
        return e1.ClassId.toString().toLowerCase().includes(
          ClassIdFilter.toString().trim().toLowerCase()
        )&& 
        e1.ClassroomType.toString().toLowerCase().includes(

          ClassroomTypeFilter.toString().trim().toLowerCase()
        )&&
        e1.ClassroomCapacity.toString().toLowerCase().includes(

          ClassroomCapacityFilter.toString().trim().toLowerCase()
        )

    });
}
}
