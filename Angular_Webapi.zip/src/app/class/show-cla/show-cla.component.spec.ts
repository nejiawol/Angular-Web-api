import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowClaComponent } from './show-cla.component';

describe('ShowClaComponent', () => {
  let component: ShowClaComponent;
  let fixture: ComponentFixture<ShowClaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowClaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowClaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
