
import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
/*import { MatCheckboxModule } from '@angular/material/checkbox';*/
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentComponent } from './student/student.component';
import { ShowStuComponent } from './student/show-stu/show-stu.component';
import { AddEditStuComponent } from './student/add-edit-stu/add-edit-stu.component';
import { CourseComponent } from './course/course.component';
import { ShowCourComponent } from './course/show-cour/show-cour.component';
import { AddEditCourComponent } from './course/add-edit-cour/add-edit-cour.component';
import { ClassComponent } from './class/class.component';
import { ShowClaComponent } from './class/show-cla/show-cla.component';
import { AddEditClaComponent } from './class/add-edit-cla/add-edit-cla.component';
import { TestComponent } from './test/test.component';
import { ShowTesComponent } from './test/show-tes/show-tes.component';
import { AddEditTesComponent } from './test/add-edit-tes/add-edit-tes.component';
import { SharedService} from './shared.service';
import{HttpClientModule} from '@angular/common/http';   
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import{ MatFormFieldModule} from '@angular/material/form-field';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatTableModule} from '@angular/material/table';
import {MatButtonModule} from '@angular/material/button';


@NgModule({
  declarations: [
    AppComponent,
    StudentComponent,
    ShowStuComponent,
    AddEditStuComponent,
    CourseComponent,
    ShowCourComponent,
    AddEditCourComponent,
    ClassComponent,
    ShowClaComponent,
    AddEditClaComponent,
    TestComponent,
    ShowTesComponent,
    AddEditTesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    MatSelectModule,
    MatInputModule,
    MatFormFieldModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatButtonModule
   
  ],
  providers: [SharedService],
  bootstrap: [AppComponent],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
