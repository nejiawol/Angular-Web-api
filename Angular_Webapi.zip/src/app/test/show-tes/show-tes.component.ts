import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-show-tes',
  templateUrl: './show-tes.component.html',
  styleUrls: ['./show-tes.component.css']
})
export class ShowTesComponent implements OnInit {

  constructor(private service:SharedService) { }
  TestList:any=[];
  ModalTitle:string;
  ActivateAddEdittescomp:boolean=false;
  tes:any;

  StudentidFilter:string="";
  CourseidFilter:string="";
  TestresultFilter:string="";
  TestListwithoutFilter:any=[];


  ngOnInit(): void {
    this.refreshteslist();
  }

  addClick(){

    this.tes={
      Studentid:0,
      Courseid:0,
      Testresult:"",
}
    this.ModalTitle="Add Test";
    this.ActivateAddEdittescomp=true;

  }

  editClick(item){
      this.tes=item;
      this.ModalTitle="Edit Test";
      this.ActivateAddEdittescomp=true;

  }

  deleteClick(item){
     if(confirm('are you sure!')){
         this.service.deleteTest(item.Studentid).subscribe(data=>{
            alert(data.toString());
            this.refreshteslist();

         })
     }

  }
  closeClick(){

    this.ActivateAddEdittescomp=false;
    this.refreshteslist();
  }


  refreshteslist(){
    this.service.getTestList().subscribe(data=>{
        this.TestList=data;
        this.TestListwithoutFilter=data;
    });
  }

  FiFun(){

    var StudentidFilter= this.StudentidFilter;
    var CourseidFilter= this.CourseidFilter;
    var TestresultFilter= this.TestresultFilter;

    this.TestList= this.TestListwithoutFilter.filter(function (e1){
        return e1.Studentid.toString().toLowerCase().includes(
          StudentidFilter.toString().trim().toLowerCase()
        )&& 
        e1.Courseid.toString().toLowerCase().includes(

          CourseidFilter.toString().trim().toLowerCase()
        )&&
        e1.Testresult.toString().toLowerCase().includes(

          TestresultFilter.toString().trim().toLowerCase()
        )

    });
}
}

