import { Component, OnInit,Input } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-tes',
  templateUrl: './add-edit-tes.component.html',
  styleUrls: ['./add-edit-tes.component.css']
})
export class AddEditTesComponent implements OnInit {

  constructor(private service:SharedService) { }
  @Input() tes:any;

  Studentid:string;
  Courseid:string;
  Testresult:string;




  ngOnInit(): void {
    this.Studentid=this.tes.Studentid;
    this.Courseid=this.tes.Courseid;
    this.Testresult=this.tes.Testresult;
 
  }

  Addtest(){
    var val = { Studentid:this.Studentid,
               Courseid:this.Courseid,
               Testresult:this.Testresult};
          this.service.addTest(val).subscribe(res=>{
            alert(res.toString());
          });
    
            }

        
  Edittest(){
    var val = { Studentid:this.Studentid,
      Courseid:this.Courseid,
      Testresult:this.Testresult
     };
 this.service.updateTest(val).subscribe(res=>{
   alert(res.toString());
 });

  }
}
