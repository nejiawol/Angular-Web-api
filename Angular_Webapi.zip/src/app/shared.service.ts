import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class SharedService {
  readonly APIUrl ="http://localhost:63283/api";
  readonly PhotoUrl ="http://localhost:63283/photos";
  constructor(private http:HttpClient) { }

  getStuList():Observable<any[]>{
    return this.http.get<any>(this.APIUrl+'/Student')
  }

  addStudent(val:any){
    return this.http.post<any>(this.APIUrl+'/Student',val)
  }
  updateStudent(val:any){
    return this.http.put<any>(this.APIUrl+'/Student',val)
  }
  deleteStudent(val:any){
    return this.http.delete<any>(this.APIUrl+'/Student/'+val)
  }


  getCourseList():Observable<any[]>{
    return this.http.get<any>(this.APIUrl+'/Course')
  }

  addCourse(val:any){
    return this.http.post<any>(this.APIUrl+'/Course',val)
  }
  updateCourse(val:any){
    return this.http.put<any>(this.APIUrl+'/Course',val)
  }
  deleteCourse(val:any){
    return this.http.delete<any>(this.APIUrl+'/Course/'+val)
  }

  getClassList():Observable<any[]>{
    return this.http.get<any>(this.APIUrl+'/Class')
  }

  addClass(val:any){
    return this.http.post<any>(this.APIUrl+'/Class',val)
  }
  updateClass(val:any){
    return this.http.put<any>(this.APIUrl+'/Class',val)
  }
  deleteClass(val:any){
    return this.http.delete<any>(this.APIUrl+'/Class/'+val)
  }
  

  getTestList():Observable<any[]>{
    return this.http.get<any>(this.APIUrl+'/TestResult')
  }

  addTest(val:any){
    return this.http.post<any>(this.APIUrl+'/TestResult',val)
  }
  updateTest(val:any){
    return this.http.put<any>(this.APIUrl+'/TestResult',val)
  }
  deleteTest(val:any){
    return this.http.delete<any>(this.APIUrl+'/TestResult/'+val)
  }

  Uploadphoto(val:any){
    return this.http.post<any>(this.APIUrl+'/Student/SaveFile',val)
  }
  getallCourses():Observable<any[]>{
    return this.http.get<any>(this.APIUrl+'/Student/GetallcoursesNames()');
  }
}
